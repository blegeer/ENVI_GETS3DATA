.. ref-awslambda

==========
AWS Lambda
==========

boto.awslambda
--------------

.. automodule:: boto.awslambda
   :members:
   :undoc-members:

boto.awslambda.layer1
---------------------

.. automodule:: boto.awslambda.layer1
   :members:
   :undoc-members:

boto.awslambda.exceptions
-------------------------

.. automodule:: boto.awslambda.exceptions
   :members:
   :undoc-members:
