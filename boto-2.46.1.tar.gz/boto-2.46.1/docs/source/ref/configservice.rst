.. ref-configservice

======
Config
======

boto.configservice
------------------

.. automodule:: boto.configservice
   :members:
   :undoc-members:

boto.configservice.layer1
-------------------------

.. automodule:: boto.configservice.layer1
   :members:
   :undoc-members:

boto.configservice.exceptions
-----------------------------

.. automodule:: boto.configservice.exceptions
   :members:
   :undoc-members:
